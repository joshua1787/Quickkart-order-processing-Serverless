import json
import boto3
import os

sqs = boto3.client('sqs')
def lambda_handler(event,context):

    body = json.loads(events['body'])

    if not body.get('name') or not body.get('email') or not body.get('product'):
        return {
            'statusCode': 400,
            'body': json.dumps({
                'message': 'Missing required fields'
            })
        }
    
    # Create the message

    response = sqs.send_message(
        QueueUrl=os.environ['SQS_QUEUE_URL'],
        MessageBody=json.dumps(body)
    )
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Order submitted successfully',
            
        })
    }
